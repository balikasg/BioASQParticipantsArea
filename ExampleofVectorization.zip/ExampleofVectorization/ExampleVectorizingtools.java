package bioasq.tools;

import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
import org.apache.lucene.analysis.en.EnglishAnalyzer;
import org.apache.lucene.util.Version;

public class ExampleVectorizingtools {
	
	
	  public static List<String> tokenizeString(Analyzer analyzer, String string) {
		    List<String> result = new ArrayList<String>();
		    try {
		      TokenStream stream  = analyzer.tokenStream(null, new StringReader(string));
		      while (stream.incrementToken()) {
		        result.add(stream.getAttribute(CharTermAttribute.class).toString());
		      }
		    } catch (IOException e) {
		       throw new RuntimeException(e);
		    }
		    return result;
		  }
	  
	public static void main(String[] args) {	
		System.out.println(ExampleVectorizingtools.tokenizeString(new EnglishAnalyzer(Version.LUCENE_36), "As a key component of the plasminogen activation system, uPAR, the receptor for the plasminogen activator of the urokinase type, is involved in many physiological and pathological processes. Besides its classical roles, there has been increased evidence that uPAR or uPAR-associated pathways, participate in the development, in the functioning and in the pathology of the central nervous system. Qualitative and quantitative changes in the expressions of uPAR and of its canonical ligand uPA have been observed in a large variety of epileptic disorders, either in human or in animal models, as well as in other brain diseases (stroke and brain trauma, multiple sclerosis, Alzheimer's disease, cerebral malaria, HIV-associated leukoencephalopathy and encephalitis). The variety of such pathological conditions and the different brain areas and cell types involved, likely reflects the wide range and the complexity of the multiple and somehow intertwined pathophysiological mechanisms related with uPAR. In the mouse, the knock-out of the Upar-encoding gene (Plaur) leads to significant and nearly complete loss in parvalbumin-containing interneurons during brain development. This is associated with increased susceptibility to spontaneous and chemically-induced seizures and with increased anxiety and impaired social interactions. The recent identification of the novel uPAR ligand SRPX2 (Sushi repeat protein, X-linked 2) and the regulation of both the SRPX2 and PLAUR genes by transcription factor FOXP2 has shed novel and exciting insights into the role of uPAR-related molecular networks in rolandic epilepsy, in developmental verbal dyspraxia, in perisylvian polymicrogyria, and generally in disorders of the speech areas and circuits. uPAR, its regulators and partners, as well as other proteins containing Ly-6/uPAR/alpha-neurotoxin domains, represent key entry points for present and future studies not only on speech-related disorders but also on epilepsy and autism spectrum disorders."));
		
	}

}
