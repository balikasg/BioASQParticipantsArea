File statistics:

    4 tar.gz files
        2,3G 2014-03-05 11:00 articles.A-B.tar.gz
        1,8G 2014-03-05 11:21 articles.C-H.tar.gz
        2,7G 2014-03-05 12:43 articles.I-N.tar.gz
        3,3G 2014-03-05 13:29 articles.O-Z.tar.gz
    Number of articles contained in the tar.gz files:
        Overall: 755686
        articles.A-B.tar.gz 171514
        articles.C-H.tar.gz 136909
        articles.I-N.tar.gz 245285
        articles.O-Z.tar.gz 201978
    Number of articles in the file listing:
        758320 ( > 755686)
    Number of PMC articles without PMID:
        58401
    Number of PMC articles without Fulltext (sections):
        76185
    Number of PMC articles contained in the set:
        621100

Fixes:

    Fixed Article title
    Fixed: Article sections started with "INTRODUCTION" followed directly by the text without a separating space.
    Try to get the pmid if missing from the documents (via NCBI mapping file: PMC-ids.csv.gz)
    Improved printed messages on conversion.
    Explicitly set input character encoding to UTF-8 (greek letters, dashes etc.).
    An example output of the process is given in the jar file, to let the participants see what is considered "normal".


Todos for participants:

    additionally download the file PMC-ids.csv.gz from ftp://ftp.ncbi.nlm.nih.gov/pub/pmc/PMC-ids.csv.gz
    Use the attached variant of the BioASQ Tasks jar
